* convert core to use `[]byte` vs. `*os.File`
* generate test cases
* finish web server integration
* add SHA256 to pkcs7 lib
