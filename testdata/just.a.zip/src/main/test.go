package main

import (
	"io/ioutil"
	"os"

	"playground/apksign"
	"playground/log"
)

func loadFile(name string) ([]byte, error) {
	var f *os.File
	var err error
	var b []byte
	if f, err = os.Open(name); err != nil {
		return nil, err
	}
	if b, err = ioutil.ReadAll(f); err != nil {
		return nil, err
	}
	return b, err
}

func main() {
	log.SetLogLevel(log.LEVEL_DEBUG)
	log.Status("main", "begin")

	var sdkapk, unsapk, rawzip []byte
	var err error


	log.Status("main", "load SDK APK")
	if sdkapk, err = loadFile("/home/morrildl/tmp/app-debug.apk"); err != nil {
		log.Error("main", "error on opening zip", err)
		return
	}
	log.Status("main", "load unsigned APK")
	if unsapk, err = loadFile("/home/morrildl/tmp/app-release-unsigned.apk"); err != nil {
		log.Error("main", "error on opening zip", err)
		return
	}
	log.Status("main", "load raw Zip")
	if rawzip, err = loadFile("/home/morrildl/tmp/just.a.zip"); err != nil {
		log.Error("main", "error on opening zip", err)
		return
	}

	var z *apksign.Zip

	log.Status("main", "test parsing SDK APK")
	if z, err = apksign.NewZip(sdkapk); err != nil {
		log.Error("main", "error parsing Zip", err)
	}
	if !z.IsAPK {
		log.Error("main", "zip is not an APK")
	}
	if !z.IsV1Signed {
		log.Error("main", "zip is not V1 (JAR) signed")
	}
	if !z.IsV2Signed {
		log.Error("main", "zip is not V2 signed")
	}

	log.Status("main", "test parsing unsigned APK")
	if z, err = apksign.NewZip(unsapk); err != nil {
		log.Error("main", "error parsing Zip", err)
	}
	if !z.IsAPK {
		log.Error("main", "zip is not an APK")
	}
	if z.IsV1Signed {
		log.Error("main", "unsigned zip is reporting as V1 (JAR) signed")
	}
	if z.IsV2Signed {
		log.Error("main", "unsigned zip is reporting as V2 signed")
	}

	log.Status("main", "test parsing raw Zip")
	if z, err = apksign.NewZip(rawzip); err != nil {
		log.Error("main", "error parsing Zip", err)
	}
	if z.IsAPK {
		log.Error("main", "zip is reporting as an APK")
	}
	if z.IsV1Signed {
		log.Error("main", "unsigned zip is reporting as V1 (JAR) signed")
	}
	if z.IsV2Signed {
		log.Error("main", "unsigned zip is reporting as V2 signed")
	}

	log.Status("main", "test verifying SDK APK signature")
	if z, err = apksign.NewZip(sdkapk); err != nil {
		log.Error("main", "error parsing Zip", err)
	}
	if err = z.VerifyV1(); err == nil {
		log.Error("main", "v2-signed zip passes v1-only verify")
	}
	if err = z.VerifyV2(); err != nil {
		log.Error("main", "v2-signed zip fails v2-only verify")
	}
	if err = z.Verify(); err != nil {
		log.Error("main", "v2-signed zip fails generic verify")
	}

	keys := []*apksign.SigningKey{
		&apksign.SigningKey{
			CertPath: "./signing.crt",
			KeyPath: "./signing.key",
			Type: apksign.RSA,
			Hash: apksign.SHA256,
		},
	}

	log.Status("main", "test signing unsigned apk")
	if z, err = apksign.NewZip(unsapk); err != nil {
		log.Error("main", "error parsing Zip", err)
	}
	if z, err = z.Sign(keys); err != nil {
		log.Error("main", "error signing apk", err)
	}
	if err = z.VerifyV1(); err == nil {
		log.Error("main", "v2-signed apk passes v1 verify")
	}
	if err = z.VerifyV2(); err != nil {
		log.Error("main", "v2-signed apk fails v2 verify", err)
	}
	if err = z.Verify(); err != nil {
		log.Error("main", "v2-signed apk fails verify", err)
	}
	if !z.IsAPK || !z.IsV1Signed || !z.IsV2Signed {
		log.Error("main", "v2-signed apk incorrectly characterized", z.IsAPK, z.IsV1Signed, z.IsV2Signed)
	}

	log.Status("main", "test signing unsigned zip")
	if z, err = apksign.NewZip(rawzip); err != nil {
		log.Error("main", "error parsing Zip", err)
	}
	if z, err = z.Sign(keys); err != nil {
		log.Error("main", "error signing zip", err)
	}
	if err = z.VerifyV1(); err == nil {
		log.Error("main", "v2-signed zip passes v1 verify")
	}
	if err = z.VerifyV2(); err != nil {
		log.Error("main", "v2-signed zip fails v2 verify", err)
	}
	if err = z.Verify(); err != nil {
		log.Error("main", "v2-signed zip fails verify", err)
	}
	if z.IsAPK || !z.IsV1Signed || !z.IsV2Signed {
		log.Error("main", "v2-signed apk incorrectly characterized", z.IsAPK, z.IsV1Signed, z.IsV2Signed)
	}

	log.Status("main", "resign previously signed zip")
	if z, err = apksign.NewZip(sdkapk); err != nil {
		log.Error("main", "error parsing Zip", err)
	}
	if z, err = z.Sign(keys); err != nil {
		log.Error("main", "error signing zip", err)
	}
	if err = z.VerifyV1(); err == nil {
		log.Error("main", "v2-signed zip passes v1 verify")
	}
	if err = z.VerifyV2(); err != nil {
		log.Error("main", "v2-signed zip fails v2 verify", err)
	}
	if err = z.Verify(); err != nil {
		log.Error("main", "v2-signed zip fails verify", err)
	}
	if !z.IsAPK || !z.IsV1Signed || !z.IsV2Signed {
		log.Error("main", "v2-signed apk incorrectly characterized", z.IsAPK, z.IsV1Signed, z.IsV2Signed)
	}

	log.Status("main", "done")
}
