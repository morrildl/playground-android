package main

import (
	"io/ioutil"
	"os"

	"playground/apksign"
	"playground/log"
)

func main() {
	log.SetLogLevel(log.LEVEL_DEBUG)
	log.Status("main", "begin")

	log.Status("main", "verify SDK APK")
	f, err := os.Open("/home/morrildl/tmp/app-debug.apk")
	if err != nil {
		log.Error("main", "error on opening zip", err)
		return
	}
	buf, err := ioutil.ReadAll(f)
	if err != nil {
		log.Error("main", "error on reading zip", err)
		return
	}

	wr := apksign.NewV1Writer()
	r, err := apksign.ParseZip(buf, wr)
	if err != nil {
		log.Error("main", "error on loading zip", err)
		return
	}
	if r.Verify() {
		log.Status("main", "input verifies")
	} else {
		log.Status("main", "input fails")
	}


	log.Status("main", "(re)sign our zip")
	keys := []*apksign.SigningKey{
		&apksign.SigningKey{
			CertPath: "./signing.crt",
			KeyPath: "./signing.key",
			Type: apksign.RSA,
			Hash: apksign.SHA256,
		},
	}
	for _, k := range keys {
		k.Resolve()
	}
	err = wr.Sign(keys, false)
	if err != nil {
		log.Status("main", "failure during sign", err)
	}
	buf, err = wr.Marshal()
	if err != nil {
		log.Status("main", "failure during marshal", err)
	}
	f, err = os.Create("./out.zip")
	if err != nil {
		log.Status("main", "failure during marshal", err)
	}
	defer f.Close()
	f.Write(buf)


	log.Status("main", "verify our signed zip")
	f, err = os.Open("./out.zip")
	if err != nil {
		log.Error("main", "error on opening zip", err)
		return
	}
	buf, err = ioutil.ReadAll(f)
	if err != nil {
		log.Error("main", "error on reading zip", err)
		return
	}

	r, err = apksign.ParseZip(buf, nil)
	if err != nil {
		log.Error("main", "error on loading zip", err)
		return
	}
	if r.Verify() {
		log.Status("main", "input verifies")
	} else {
		log.Status("main", "input fails")
	}
}
