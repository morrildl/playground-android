package main

import (
	"playground/apksign"
	"playground/log"
)

func main() {
	log.SetLogLevel(log.LEVEL_DEBUG)
	log.Status("main", "begin")

	log.Status("main", "verify SDK APK")
	z, err := apksign.NewZip("/home/morrildl/tmp/app-debug.apk")
	if err != nil {
		log.Error("main", "error on loading zip", err)
		return
	}
	if z.VerifyV2() {
		log.Status("main", "input verifies")
	} else {
		log.Status("main", "input fails")
	}

	log.Status("main", "verify our signed zip")
	z, err = apksign.NewZip("/home/morrildl/tmp/app-release-unsigned.apk-signed")
	if err != nil {
		log.Error("main", "error on loading zip", err)
		return
	}
	if z.VerifyV2() {
		log.Status("main", "input verifies")
	} else {
		log.Status("main", "input fails")
	}

	log.Status("main", "re-sign our zip")
	keys := []*apksign.SigningKey{
		&apksign.SigningKey{
			CertPath: "./signing.crt",
			KeyPath: "./signing.key",
			Type: apksign.RSA,
			Hash: apksign.SHA256,
		},
	}
	z, err = apksign.NewZip("/home/morrildl/tmp/app-release-unsigned.apk")
	err = z.SignV2(keys)
	if err != nil {
		log.Status("main", "failure during sign", err)
	} else {
		log.Status("main", "signing success")
	}
}
